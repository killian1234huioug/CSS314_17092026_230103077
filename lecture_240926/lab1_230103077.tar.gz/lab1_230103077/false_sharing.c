#include <stdio.h>
#include <stdint.h>
#include <mach/mach_time.h>
#include <omp.h>

#define N 13077000ULL
#define MAX_THREADS 64

static inline uint32_t collatz_steps(uint64_t n)
{
    uint32_t steps = 0;

    while (n > 1) {
        if ((n & 1ULL) == 0)
            n >>= 1;
        else
            n = 3 * n + 1;

        steps++;
    }

    return steps;
}

static double get_time(void)
{
    static mach_timebase_info_data_t timebase;

    if (timebase.denom == 0)
        mach_timebase_info(&timebase);

    return (double)mach_absolute_time()
           * (double)timebase.numer
           / (double)timebase.denom
           / 1e9;
}

int main(void)
{
    int threads = 8;

    omp_set_num_threads(threads);

    int hit_count[MAX_THREADS] = {0};

    double start = get_time();

    #pragma omp parallel for
    for (uint64_t i = 1; i <= N; i++) {
        uint32_t steps = collatz_steps(i);

        if (steps > 100) {
            int tid = omp_get_thread_num();
            hit_count[tid]++;
        }
    }

    double end = get_time();

    int total_hits = 0;

    for (int i = 0; i < threads; i++)
        total_hits += hit_count[i];

    double time = end - start;
    double throughput = (double)N / time;

    printf("Variant: Naive False Sharing\n");
    printf("Threads: %d\n", threads);
    printf("Total hits (>100 steps): %d\n", total_hits);
    printf("Execution time: %.9f seconds\n", time);
    printf("Effective throughput: %.2f iter/sec\n", throughput);

    return 0;
}
