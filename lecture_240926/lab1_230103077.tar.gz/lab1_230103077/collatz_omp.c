#include <stdio.h>
#include <stdint.h>
#include <mach/mach_time.h>

#define N 13077000ULL
#define MOD 1000000007ULL

static inline uint32_t collatz_steps(uint64_t n)
{
    uint32_t steps = 0;

    while (n > 1) {
        if ((n & 1ULL) == 0)
            n >>= 1;
        else
            n = 3 * n + 1;

        steps++;
    }

    return steps;
}

static double get_time(void)
{
    static mach_timebase_info_data_t timebase;

    if (timebase.denom == 0)
        mach_timebase_info(&timebase);

    return (double)mach_absolute_time()
           * (double)timebase.numer
           / (double)timebase.denom
           / 1e9;
}

int main(void)
{
    uint64_t sum = 0;
    uint32_t max_steps = 0;

    double start = get_time();

    for (uint64_t i = 1; i <= N; i++) {
        uint32_t steps = collatz_steps(i);

        sum += steps;

        if (steps > max_steps)
            max_steps = steps;
    }

    sum %= MOD;

    double end = get_time();

    printf("Student ID: 230103077\n");
    printf("N: %llu\n", N);
    printf("Maximum stopping time: %u\n", max_steps);
    printf("Checksum: %llu\n", sum);
    printf("Execution time: %.9f seconds\n", end - start);

    return 0;
}
